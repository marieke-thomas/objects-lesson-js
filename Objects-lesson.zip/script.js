let cutekitty32 = ["Hera", "Thomas", 10, "tabby", "American shorthair", "twist ties", 9, "napping"]

// print out Hera's fur color


//print out Hera's last name


//print out Hera's age


