// CRUD: Create
cutekitty32 = {
  "first_name":"Hera",
  "last_name":"Thomas", 
  "age":10, 
  "fur color":"tabby", 
  "breed":"American shorthair", 
  "favorite toy":"twist ties", 
  "weight":9, 
  "favorite activity":"napping"
}

// Read


// Update


//Delete


//Challenges! The last line prints the whole object so you can check if your updates are working by uncommenting it!
//1 Print out Hera's breed


//2 Hera got bored of twist ties. Change her favorite toy to "catnip mouse"


//3 Hera's profile is incomplete! Come up with another category and response, and add them to the object


//4 Delete Hera's weight from the object


// 5 Hera's favorite nap spot is "couch". Add that to the profile


// 6 Print Hera's fav nap spot


//7 Challenge: A lot of sites include a section for what someone is looking for. Create a list of 3 adjectives that Hera is looking for in a kitty friend and add the list to the object (you will have a list within an object)



// 8 Challenge: Print out the second of the adjectives that you just came up. Your code should start with: console.log(cutekitty32



//9 Super Challenge! For each category in the profile, print out a statement that says "Hera's ____ is ____" and fill in the blanks. (You will probably need to use Google to help you)

//console.log(cutekitty32)